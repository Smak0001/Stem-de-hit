export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-ZYnaiSxb.js\")",
  "clientReferenceDeps": {
    "92f5c1cd8d45": {
      "js": [
        "/_next/static/chunks/party-app-CfdN6h3d.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-ZYnaiSxb.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-C6Jp29r4.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js",
        "/_next/static/chunks/app-route-prefetch-policy-BtEwFbYo.js",
        "/_next/static/chunks/query-DWOJKAZx.js"
      ],
      "css": []
    },
    "fa00f422d923": {
      "js": [
        "/_next/static/chunks/index-ZYnaiSxb.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-C6Jp29r4.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "d75075fbc01d": {
      "js": [
        "/_next/static/chunks/index-ZYnaiSxb.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-C6Jp29r4.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "16d20fe1d547": {
      "js": [
        "/_next/static/chunks/index-ZYnaiSxb.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-C6Jp29r4.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "7e184562052a": {
      "js": [
        "/_next/static/chunks/index-ZYnaiSxb.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-C6Jp29r4.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "5e3dc4edabfe": {
      "js": [
        "/_next/static/chunks/layout-segment-context-BR3xAnPP.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-ZYnaiSxb.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-C6Jp29r4.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "e9df119fdb7b": {
      "js": [
        "/_next/static/chunks/index-ZYnaiSxb.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-C6Jp29r4.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    },
    "e203c127af17": {
      "js": [
        "/_next/static/chunks/streamed-icons-UVeKuoEd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/index-ZYnaiSxb.js",
        "/_next/static/chunks/app-elements-H_Dr48wG.js",
        "/_next/static/chunks/hash-Cp347hhd.js",
        "/_next/static/chunks/record-uXSNv6cl.js",
        "/_next/static/chunks/app-rsc-cache-busting-C6Jp29r4.js",
        "/_next/static/chunks/app-rsc-render-mode-CvTCGruk.js",
        "/_next/static/chunks/headers-C_MtfdF4.js",
        "/_next/static/chunks/protocol-headers-B9-bVeat.js",
        "/_next/static/chunks/deployment-id-DFhHa9wO.js",
        "/_next/static/chunks/navigation-errors-D5LMQqDL.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.CEzlTPAD.css"
      ]
    }
  }
}